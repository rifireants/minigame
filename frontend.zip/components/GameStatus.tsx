'use client'

import { useEffect, useState } from 'react'
import { BsDice6 } from "react-icons/bs";

interface GameStatusData {
  roundId: number
  status: string
  startedAt: string
  currentAt: string
}

export default function GameStatus() {
  const [round, setRound] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<string>("--:--");
  const [startTime, setStartTime] = useState<string>("");
  const [endTime, setEndTime] = useState<string>("");

  useEffect(() => {
    const fetchRound = async () => {
      try {
        const token = localStorage.getItem("token")
        const res = await fetch("http://localhost:3001/rounds/current", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }); // 백엔드 주소에 맞게 수정
        const data = await res.json();
        setRound(data.round);
        setTimeLeft(data.timeLeft);
        setStartTime(new Date(data.startTime).toLocaleTimeString([], {
          hour: '2-digit', minute: '2-digit'
        }));
        setEndTime(new Date(data.endTime).toLocaleTimeString([], {
          hour: '2-digit', minute: '2-digit'
        }));
      } catch (err) {
        console.error("게임 상태 불러오기 실패:", err);
      }
    };

    fetchRound();
    const interval = setInterval(fetchRound, 10000); // 10초마다 갱신
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="card round-info bg-[#2c3e50] text-white border-0 rounded-2xl shadow-2xl m-4">
      <div className="card-body p-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <BsDice6 className="text-3xl mr-3" />
            <div>
              <p className="mb-1 opacity-75">현재 진행중인 회차</p>
              <h5 className="mb-0 font-bold">{round ? `${round}회차` : "로딩중..."}</h5>
            </div>
          </div>
          <div className="text-right">
            <p className="mb-1 opacity-75">베팅 마감까지</p>
            <div className="text-4xl font-bold text-yellow-400" id="countdown">{timeLeft}</div>
            <small className="text-white opacity-50">{endTime}에 마감</small>
          </div>
        </div>

        {/* 게임 상태 표시 */}
        <div className="mt-2">
          <span className="badge bg-green-500 text-white px-2 py-1 rounded-full">베팅 가능</span>
          <small className="text-white opacity-50 ml-2">지금 베팅하세요!</small>
          {/* 디버깅용 시간 정보 (관리자만) */}
          <div className="mt-1">
            <small className="text-white opacity-50 text-sm">
              현재: 13:12:26 | 시작: 13:12:23 | 마감: 13:15:03 | 결과: 13:15:13
            </small>
          </div>
        </div>
      </div>
    </div>
  );
}
