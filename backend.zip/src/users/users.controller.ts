import { Controller, Get, Post, Put, Delete, Param, Body, NotFoundException, UseGuards, Res } from '@nestjs/common';
import { Response } from 'express';
import { UsersService } from './users.service';
import { User } from './user.entity';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) { }

  @Get()
  async findAll(@Res() res: Response): Promise<void> {
    const users = await this.usersService.findAll();
    res.setHeader('Content-Range', `users 0-${users.length - 1}/${users.length}`);
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range');
    res.json(users.map(({ password, ...rest }) => rest));
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<any> {
    const user = await this.usersService.findOne(+id);
    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }
    const { password, ...rest } = user;
    return rest;
  }

  @Post()
  async create(@Body() user: User): Promise<void> {
    await this.usersService.create(user);
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() user: Partial<User>): Promise<void> {
    await this.usersService.update(+id, user);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<void> {
    await this.usersService.remove(+id);
  }
}
